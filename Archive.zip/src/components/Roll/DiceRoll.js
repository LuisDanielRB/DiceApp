
const DiceRoll = (n) => {
  return Math.floor(Math.random() * n ) + 1;
}
 
export default DiceRoll;