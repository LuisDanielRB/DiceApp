import React from "react";
import D4 from "../DiceIMG/D4";
import D6 from "../DiceIMG/D6";
import D8 from "../DiceIMG/D8";
import D10 from "../DiceIMG/D10";
import D12 from "../DiceIMG/D12";
import D20 from "../DiceIMG/D20";

const NumberDisplay = (props) => {
  switch (props.faces) {
    case 4:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D4 className="flex mx-auto my-4" />
          </div>
        </div>
      );
    case 6:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D6 className="flex mx-auto my-4" />
          </div>
        </div>
      );
    case 8:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D8 className="flex mx-auto my-4" />
          </div>
        </div>
      );
    case 10:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D10 className="flex mx-auto my-4" />
          </div>
        </div>
      );
    case 12:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D12 className="flex mx-auto my-4" />
          </div>
        </div>
      );
    case 20:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>
            {props.diceNumber}
            <D20 className="flex mx-auto my-4" />
          </div>
        </div>
      );

    default:
      return (
        <div>
          <div className={`text-center text-8xl mt-5`}>{props.diceNumber}</div>
        </div>
      );
  }
};

export default NumberDisplay;
